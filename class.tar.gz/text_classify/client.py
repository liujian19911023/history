#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os, sys
from use_w2v import W2VClassify
import re
import json
import jieba
import jieba.analyse
import jieba.posseg as pos
from format_class import Conf
from genClassify_client import ClientGeneralClassify
project_dir = os.path.dirname(os.path.abspath(__file__))
cgc = ClientGeneralClassify()
reload(sys)
sys.setdefaultencoding('utf-8')


class TopicClassify():

    def __init__(self, file_name):

        self.clfconf = self.load_clf(file_name)
        self.init_re()

    def init_re(self):
        self.re1 = re.compile('^新华社照片，.{2,6}，\d{4}年\d{1,2}月\d{1,2}日')
        self.re2 = re.compile('.*新华社记者.+摄.*')
        self.re3 = re.compile('.*新华社.+报道.*')
        self.re4 = re.compile('^新华社图表，.{2,6}，\d{4}年\d{1,2}月\d{1,2}日')
        self.re5 = re.compile('^新华社照片,.{2,6},\d{4}年\d{1,2}月\d{1,2}日')
        self.re6 = re.compile('^新华社图表,.{2,6},\d{4}年\d{1,2}月\d{1,2}日')
        self.re7 = re.compile('\w{5,60}')
        #self.re8 = re.compile('[a-z]|[A-Z]')
        self.re9 = re.compile('\d{4}年\d{1,2}月\d{1,2}日|\d{4}-\d{1,2}-\d{1,2}')

    def preprocess(self, content):
        if isinstance(content, unicode):
            content = content.strip()
            content = content.encode('utf-8')
        old_content = content
        try:
            sub_content_list = content.split('\r\n')
            new_content = ''
            for sub_content in sub_content_list:
                sub_content = sub_content.strip()
                #sub_content = re.sub(self.re8, '', sub_content)
                sub_content = re.sub(self.re9, '', sub_content)
                #print len(sub_content)
                if '新华社' in sub_content and len(sub_content) < 30:
                    continue
                if '新华社外代图片' in sub_content or '新华社/' in sub_content or '[SIPA]' in sub_content:
                    if len(sub_content) < 60:
                        continue
                sub_content = sub_content.replace(' ','')
                match1 = self.re1.match(sub_content)
                match2 = self.re2.match(sub_content)
                match3 = self.re3.match(sub_content)
                match4 = self.re4.match(sub_content)
                match5 = self.re5.match(sub_content)
                match6 = self.re6.match(sub_content)
                match7 = self.re7.match(sub_content)
                sub_content = re.sub(re.compile('【.*?】'), ' ', sub_content)
                #sub_content = re.sub(re.compile('《.*?》'), ' ', sub_content)
                #sub_content = re.sub(re.compile('\(.*?\)'), ' ', sub_content)
                sub_content = re.sub(re.compile('记者.*?摄'), ' ', sub_content)
                sub_content = re.sub(re.compile('-{2,}'), ' ', sub_content)
                sub_content = re.sub(re.compile('\.{2,}'), ' ', sub_content)
                if match1 or match2 or match3 or match4 or match5 or match6 or match7:
                    if len(sub_content) < 60:
                        continue
                new_content += sub_content + ' '
            return new_content
        except:
            return old_content
    def load_clf(self,file_name):
        conf=Conf()
        return conf.loadConf(file_name)
    def load_clf_bak(self, file_name):
        clf_dict = {}
        clf2zw_dict = {}
        for line in open(file_name):
            line = line.strip()
            if line == '':
                continue
            columns = line.split('\t')
            clf = columns[0].strip()
            zw = columns[1].strip()
            clf2zw_dict[clf] = zw
            words_str = columns[2].strip()
            words_list = words_str.split(',')
            for word in words_list:
                if word == '':
                    continue
                clf_dict[word] = clf
        print clf_dict
        print clf2zw_dict
        return clf_dict,clf2zw_dict
    '''
        将类目作为参数传递
    '''
    def getAllFirstLevel(self,level_tree=None):
        keywords=[]
        anti_map={}
        c_ids={}
        tmp= self.clfconf if level_tree==None else level_tree
        for key in tmp:
            keyword=tmp[key]["keywords"]
            if keyword=="":
                continue
            keywords.append(keyword)
            anti_map[keyword]=key
            c_ids[key]=tmp[key]["cid"]
        return keywords,anti_map,c_ids
    def getSubLevelChild(self,path):
        paths=path.split("\001")
        tmp=None
        if len(paths)==1:
            if "childs" in self.clfconf[paths[0]]:
                tmp=self.clfconf[paths[0]]["childs"]
        elif len(paths)==2:
            if "childs" in self.clfconf[paths[0]]["childs"][paths[1]]:
                tmp=self.clfconf[paths[0]]["childs"][paths[1]]["childs"]
        elif len(paths)==3:
            if "childs" in self.clfconf[paths[0]]["childs"][paths[1]]["childs"][paths[2]]:
                tmp=self.clfconf[paths[0]]["childs"][paths[1]]["childs"][paths[2]]["childs"]
        elif len(paths)==4:
            pass
        if tmp==None:
            return None,None,None
        else:
            return self.getAllFirstLevel(tmp)
    def filter_doc(self,document):
        http_pat = ur'(?:(?:https?:)|(?:www)|(?:wap))[\w\.\&\/\=\:\?%\-]+'
        document = re.sub(http_pat, u"", document)
        return document
    
    def extract_feature_bak(self,document):
        words=pos.cut(document)
        d_words={}
        for word in words:
            if len(word.word)>1 and word.flag in ['n','v'] :
                d_words[word.word]=d_words.get(word.word,0)+1
        ret=[]
        s=""
        for w in d_words.items():
            ret.append(w[0]+"|"+str(w[1]))
            s=s+w[0]+" "
        print s
        return ret
    
    def extract_feature(self,document):
        self.filter_doc(document)
        words=None
        try:
             words1=jieba.analyse.textrank(document,topK=30,withWeight=True)
             words2=jieba.analyse.extract_tags(document,topK=30,withWeight=True)
             words=list(set(words1) | set(words2))
             words1.extend(words2)
             words=words1
        except Exception as e:
            words=jieba.analyse.extract_tags(document,topK=30,withWeight=True)
        tmp={}
        nw_words=set()
        d_words=[]
        s=""
        for word in words:
            if len(word[0])>1 and not self.hasNumbers(word[0]):
                if word[0] in tmp:
                    tmp[word[0]]=(tmp.get(word[0])+word[1])/2
                else:
                    tmp[word[0]]=word[1]
        for w in tmp.items():
            d_words.append(w[0]+"|"+str(w[1]))
            nw_words.add(w[0])
            s=s+w[0]+" "
        return d_words

    def hasNumbers(self,inputString):
        return any(char.isdigit() for char in inputString)

    def _bfd_topic_classify(self,clf_words,doc_words,sport):
        res = cgc.classify(",".join(clf_words),",".join(doc_words).encode("utf-8"),sport)
        res_list = json.loads(res)
        ret=res_list[0][0]
        score=res_list[0][1]
        if score>=0.2:
            return res_list[0]
        else:
            return [u"其它",1-score]
    """
    分类调用的接口,输入为新闻内容
    """
    def bfd_topic_classify(self,document):
        res=""
        #获取一级类目及映射
        clf_words,anti_map,c_ids = self.getAllFirstLevel()
        lev=1
        #预处理，基本都是正则，可删可改
        document  = self.preprocess(document)
        #提取关键词
        doc_words = self.extract_feature(document)
        #无结果类目
        c_id="00"
        #保留每级类目的得分
        l_classify_conf = []
        #循环计算类目结构
        flag=False
        while True:
            #根据类目关键词分类
            category_score = self._bfd_topic_classify(clf_words,doc_words,flag)
            l_classify_conf.append(category_score[1])
            #如果有类目
            if category_score[0]!=u'其它':
                #根据反映射找到类目
                level=anti_map[category_score[0].encode("utf-8")]
                #规则
                if lev==2 and level=="竞技体育":
                    flag=True
                res=level if res=="" else res+"\001"+level
                c_id=c_ids[level]
                #获取下级类目和关键词映射
                clf_words,anti_map,c_ids = self.getSubLevelChild(res)
                if len(clf_words) == 0: 
                    break
            else:
                res='其它' if res=="" else res+"\001其它"
                break
            lev=lev+1
            print ">>>>result: ", res
        #求得分
        if l_classify_conf:
            class_conf = float(sum(l_classify_conf))/len(l_classify_conf)
        else:
            class_conf = 0.0

        return res.replace("\001","-"), class_conf,c_id
        
if __name__ == "__main__":
    topicClf = TopicClassify('clf.txt') 

    re1 = re.compile('\s')
    content = """诚信是衡量一个国家法治环境优劣的重要指标,构建社会诚信体系是推进法治建设的重要内容，一处失信,处处受限,一张基于政府信息共享的社会信用网正在编织,从一个侧面反映出我国社会信用体系建设的进展，健全公民和组织守法信用记 录,让失信者寸步难行,让诚信者一路畅通,最终也需要用法治保驾护航,以制度培育自觉,让诚信成为全体人民共同追求和自觉行动 """


    content = re.sub(re1, ' ', content)
    clf = topicClf.bfd_topic_classify(content)
    print '>>>>result: ', clf




    """
    #ret=topicClf.classfiy("诚信是衡量一个国家法治环境优劣的重要指标,构建社会诚信体系是推进法治建设的重要内容，一处失信,处处受限,一张基于政府信息共享的社会信用网正在编织,从一个侧面反映出我国社会信用体系建设的进展，健全公民和组织守法信用记 录,让失信者寸步难行,让诚信者一路畅通,最终也需要用法治保驾护航,以制度培育自觉,让诚信成为全体人民共同追求和自觉行动")
    #print ret
    #quit()
    re1 = re.compile('\s')
    outfi = open('119_doc'+sys.argv[2]+'.dat', 'w')
    init_label={}
    tt_label={}
    after_label={}
    lines=[]
    with  open(sys.argv[1]) as f:
        lines=f.readlines()
        for line in lines:
            line = line.strip().encode("utf-8")
            fields=line.split('\t')
            fs=fields[0].split('>')
            cate=fs[0].strip()
            #init_label[fields[0]]=init_label.get(fields[0],0)+1
            init_label[cate]=init_label.get(cate,0)+1
            line=fields[1]
            if line=='':
                continue
            clf=""
            res=""
            clf_words,anti_map=topicClf.getAllFirstLevel()
            lev=1
            document = topicClf.preprocess(line)
            #s = SnowNLP(unicode(document,"utf-8"))         
            #document=[sentence.encode("utf-8") for sentence in s.summary(6)]
            doc_words,nw_words=topicClf.extract_feature(document)
            flag=False
            while True:
                keyword_score = topicClf.bfd_topic_classify(clf_words,doc_words,flag)
                if keyword_score[0]!=u'其它':
                    level=anti_map[keyword_score[0].encode("utf-8")]
                    if lev==1 and level==cate:
                        tt_label[level]=tt_label.get(level,0)+1
                    if lev==1:
                        after_label[level]=after_label.get(level,0)+1
                    if lev==2 and level=="竞技体育":
                        flag=True
                    if lev==3 and res=='政治法律\001党派':
                        if u"中国共产党" in nw_words:
                            level="中国共产党"
                        elif ((u"民主党" in nw_words or u"共和党" in nw_words) and u"美国" in nw_words) or u"美国共和党" in nw_words or u"美国民主党" in nw_words:
                            level="美国民主党、共和党"
                        else:
                            level="其它"
                            res=res+"\001其它"
                            break
                    if level=="廉政建设" and keyword_score[1]<0.4:
                        res='其它' if res=="" else res+"\001其它"
                        break
                    res=level if res=="" else res+"\001"+level
                    clf_words,anti_map=topicClf.getSubLevelChild(res)
                    if clf_words==None:
                        break
                else:
                    res='其它' if res=="" else res+"\001其它"
                    break
                lev=lev+1
            outfi.write(res.replace('\001','>')+ '\t' + line + '\n')
    outfi.close()
    for label in init_label.items():
        print label[0],' 准确率:', float(tt_label.get(label[0],0.0))/after_label.get(label[0],1)
        print label[0],' 召回率:', float(tt_label.get(label[0],0.0))/label[1]
    
    """
