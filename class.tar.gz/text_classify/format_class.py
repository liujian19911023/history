#!/usr/bin/python
#encoding=utf-8
import sys
import json
reload(sys)
sys.setdefaultencoding('utf-8')

class Conf(object):
    """
    解析类目关键词文件，生成json格式，文件格式为id pid category keywords，最多支持4级
    """
    def __init__(self):
        self.id_name={}
        self.first=[]
        self.second=[]
        self.third=[]
        self.four=[]
        self.second_first={}
        self.third_second={}
        self.four_third={}
        self.category={}
    def getName(self,cid):
        return self.id_name[cid]
    """
    解析文件，i为保留几级类目，默认为2
    """
    def loadConf(self,filename,i=2):
        root=""
        name=""
        if i>4 or i<2:
            i=2
        with open(filename)  as f:
            count=1
            for line in f:
                id_pid_cat=line.strip().encode("utf-8").split("\t")
                self.id_name[id_pid_cat[0]]=id_pid_cat[2]
                if count==1:
                    root=id_pid_cat[0]
                    name=id_pid_cat[2]
                    self.category[id_pid_cat[2]]={}
                    self.category[id_pid_cat[2]]["cid"]=id_pid_cat[0]
                    self.category[id_pid_cat[2]]["childs"]={}
                    count=count+1
                else:
                    #一级类目
                    if id_pid_cat[1]==root:
                        if len(id_pid_cat)==3:
                            keyword=""
                        else:
                            keyword=id_pid_cat[3]
                        self.category[name]["childs"][id_pid_cat[2]]={"cid":id_pid_cat[0],"keywords":keyword,"childs":{}}
                        self.first.append(id_pid_cat[0])
                    else:
                        #二级类目
                        if id_pid_cat[1] in self.first:
                            f_name=self.getName(id_pid_cat[1])
                            if len(id_pid_cat)==3:
                                keyword=""
                            else:
                                keyword=id_pid_cat[3]
                            self.category[name]["childs"][f_name]["childs"][id_pid_cat[2]]={"cid":id_pid_cat[0],"keywords":keyword,"childs":{}}
                            self.second.append(id_pid_cat[0])
                            self.second_first[id_pid_cat[0]]=id_pid_cat[1]
                        #三级类目
                        elif id_pid_cat[1] in self.second:
                            s_name=self.getName(id_pid_cat[1])
                            f_name=self.getName(self.second_first[id_pid_cat[1]])
                            if len(id_pid_cat)==3:
                                keyword=""
                            else:
                                keyword=id_pid_cat[3]
                            self.category[name]["childs"][f_name]["childs"][s_name]["childs"][id_pid_cat[2]]={"cid":id_pid_cat[0],"keywords":keyword,"childs":{}}
                            self.third.append(id_pid_cat[0])
                            self.third_second[id_pid_cat[0]]=id_pid_cat[1]
                        #四级类目
                        elif id_pid_cat[1] in self.third:
                            if i<3:
                                continue
                            t_name=self.getName(id_pid_cat[1])
                            s=self.third_second[id_pid_cat[1]]
                            s_name=self.getName(s)
                            f=self.second_first[s]
                            f_name=self.getName(f)
                            if len(id_pid_cat)==3:
                                keyword=""
                            else:
                                keyword=id_pid_cat[3]
                            self.category[name]["childs"][f_name]["childs"][s_name]["childs"][t_name]["childs"][id_pid_cat[2]]={"cid":id_pid_cat[0],"keywords":keyword,"childs":{}}
                            self.four.append(id_pid_cat[1])
                            self.four_third[id_pid_cat[0]]=id_pid_cat[1]
                        elif id_pid_cat[1] in self.four:
                            if i<4:
                                continue
                            fo_name=self.getName(id_pid_cat[1])
                            t=self.four_third[id_pid_cat[1]]
                            t_name=self.getName(t)
                            s=self.third_second[f]
                            s_name=self.getName(s)
                            f=self.second_first[s]
                            f_name=self.getName(f)
                            if len(id_pid_cat)==3:
                                keyword=""
                            else:
                                keyword=id_pid_cat[3]
                            self.category[name]["childs"][f_name]["childs"][s_name]["childs"][t_name]["childs"][fo_name]["childs"][id_pid_cat[2]]={"cid":id_pid_cat[0],"keywords":keyword,"childs":{}}
        ret={}
        for k,v in self.category.items():
            for child in v["childs"]:
                ret[child]=v["childs"][child]
        return ret

if __name__=='__main__':
    conf=Conf()
    conf.loadConf(sys.argv[1])
