#!/usr/bin/python 
# -*- coding: UTF-8 -*- #

import json
import sys, os
reload(sys)
sys.setdefaultencoding('utf-8')
cur_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()
sys.path.append(cur_dir + '/gen-py')

from general_classify import GeneralClassify
from general_classify.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol

class ClientGeneralClassify():
    def __init__(self):
        transport = TSocket.TSocket('0.0.0.0', 60002)
        self.transport = TTransport.TBufferedTransport(transport)
        protocol = TBinaryProtocol.TBinaryProtocol(self.transport)
        self.client = GeneralClassify.Client(protocol)
        self.transport.open()
    def classify(self,category_words,doc_words,sport):
        res = self.client.classify(category_words,doc_words,sport)
        return res
    def __del__(self):
        self.transport.close()

if __name__=='__main__':
    cgc = ClientGeneralClassify()
    for i in range(10):
        category_words=['表示','明星共同','并荣','功义','被乐迷','曾昭玮助','公益']
        doc_words="我,爱,北京,天安门"
        res = cgc.classify(",".join(category_words),doc_words)
        res = json.loads(res)
        for k,v in res:
            print k,v
