#!/usr/bin/python 
# -*- coding: UTF-8 -*- #

import gensim
import json
import sys, os
cur_dir = os.path.dirname( os.path.abspath(__file__)) or os.getcwd()
sys.path.append(cur_dir + '/gen-py')
from general_classify import GeneralClassify
from general_classify.ttypes import *

from thrift.transport import TSocket
from thrift.transport import TTransport
from thrift.protocol import TBinaryProtocol
from thrift.server import TServer
from thrift.server import TProcessPoolServer

from set_logger import set_logger
import logging

from use_w2v import W2VClassify

class ServiceGeneralClassify(object):
    
    def __init__(self, stopwords_path, df_model_path, w2v_model_path):
        self.wvc = W2VClassify(stopwords_path, df_model_path, w2v_model_path)
    def classify(self,category_words,doc_words,sport):
        category_words=self.wvc.decode_class_word(category_words)
        return self.wvc.classify_doc(doc_words.split(","),category_words,sport=sport)

def usage():
    print "Usage:"
    print "python server.py port processNum."

if len(sys.argv) != 3:
    usage()
else:
    set_logger(cur_dir + '/logs/genClassify_server.log')
    handler = ServiceGeneralClassify(sys.argv[3],sys.argv[4],sys.argv[5])
    processor = GeneralClassify.Processor(handler)
    transport = TSocket.TServerSocket('0.0.0.0',int(sys.argv[1]))
    tfactory = TTransport.TBufferedTransportFactory()
    pfactory = TBinaryProtocol.TBinaryProtocolFactory()
    server = TProcessPoolServer.TProcessPoolServer(processor, transport, tfactory, pfactory)
    server.setNumWorkers(int(sys.argv[2]))

    print "Starting python server..."
    server.serve()
    print "done!"

