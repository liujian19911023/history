service GeneralClassify{
    string classify(1:string category_words,2:string doc_words,3:bool sport)
}
