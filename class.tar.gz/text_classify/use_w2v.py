#!/usr/bin/env python
# -*- coding:utf-8 -*-

import os, sys, re, traceback, math, jieba, gensim, json, time
import jieba.posseg as pg
cur_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()
import logging
import numpy as np
import time
class W2VClassify(object):

    def __init__(self, stopwords_file, word_df_file, w2v_model):
        """
        初始化时会加载停用词和idf文件，但不会传入document和类目词
        """
        t1 = time.time()
        self.w2v = gensim.models.word2vec.Word2Vec.load_word2vec_format(w2v_model, binary = True)
        t2 = time.time()
        logging.info("loading w2v model finished, time consumed: %ss" %(t2 - t1))
        self.stopwords = self.load_stopwords(stopwords_file)
        t1 = time.time()
        logging.info("loading stopwords finished, time consumed: %ss" %(t1 - t2))
        self.word_df = self.load_word_df(word_df_file)
        t2 = time.time()
        logging.info("loading df model finished, time consumed: %ss" %(t2 - t1))
        self.pos_list = \
        {
            'v':2.0, \
            'vn': 1.0, \
            'vl': 1.0, \
            'l': 1.0, \
            'an': 1.0, \
            'n': 1.0, \
            'nl': 2.0, \
            'nr': 2.0, \
            'nrj': 2.0, \
            'nrt':2.0,\
            'nrf': 2.0, \
            'nrfg':2.0,\
            'ns': 1.0, \
            'nsf': 1.0, \
            'nt': 2.0, \
            'nz': 1.0, \
            'nl': 1.0, \
            'ng': 1.0, \
            'eng': 0.75, \
            'd': 0.5, \
            'a': 0.5, \
            'al': 0.5, \
        }

    def load_stopwords(self, file_path):
        s_stopwords = set()
        for line in open(file_path,'rb'):
            tmp = line.strip().decode('utf-8')
            if tmp:
                s_stopwords.add(tmp)
        return s_stopwords
    
    def load_word_df(self, file_path):
        d_word_df = {}
        for line in open(file_path):
            l_tmp = line.split('\t')
            word = l_tmp[0].strip()
            if not len(word):
                continue
            word = unicode(word, 'utf-8')
            d_word_df[word] = float(l_tmp[1])
        return d_word_df
    
    def get_word_vector(self, word, dim=150):
        try:
            if type(word) == type(""):
                word = word.decode("utf-8")
            res = self.w2v[word]
            return res.tolist()
        except Exception as e:
            #traceback.print_exc()
            return list(np.zeros(dim))

    def decode_document(self, document):
        """
        这一步会加载document为实例属性
        """
        try:
            if type(document) == type(""):
                self.document = document.decode("utf-8")
            elif type(document) == type(u""):
                self.document = document
        except Exception as e:
            traceback.print_exc()
            self.document = u""
    
    def filter_doc(self):
        http_pat = ur'(?:(?:https?:)|(?:www)|(?:wap))[\w\.\&\/\=\:\?%\-]+'
        self.document = re.sub(http_pat, u"", self.document)
        
    def word_posseg(self):
        ll_words = []
        l_sents = re.split(ur'[,"“”、\(\)（）《》，。：！？；\n]', self.document)
        time12 = time.time()
        cost = 0
        for sent in l_sents:
            time10 = time.time()
            pg_list = pg.cut(sent.strip())
            time11 = time.time()
            cost += time11-time10
            for obj in pg_list:
                time14 = time.time()
                word = obj.word.strip()
                flag = obj.flag.strip()
                #if len(word)>1 and flag not in['r'] and word not in self.stopwords:
                if (flag.startswith('v') or flag.startswith('n')) and len(word)>1 and  word not in self.stopwords:
                    ll_words.append((word,flag))
        time13 = time.time()
        logging.info('word_posseg for sent in l_sents:')
        logging.info(time13-time12)
        return ll_words
        
    def get_words_weight(self, ll_words):
        d_word_weight = {}
        for word in ll_words:
            if word[0] in d_word_weight:
                d_word_weight[word[0]][0] += 1
            else:
                d_word_weight[word[0]] = [1, word[1]]
        for k in d_word_weight:
            weight=self.get_weight_from_length(k)
            pos_weight=self.pos_list.get(d_word_weight[k][1], 0.1)
            d_word_weight[k][0] *= weight * pos_weight

        return d_word_weight
    
    def get_weight_from_length(self, word):
        weight = 0
        L = len(word)
        if re.match(ur'\w+$',word):
            L *= 0.7
        if L < 2:
            weight = 0.5
        elif 2 <= L < 3:
            weight = 1
        elif 3 <= L < 5:
            weight = 2
        else: 
            weight = 3
        return weight

    def compute_idf(self, d_words):
        for word in d_words:
            df = self.word_df.get(word.strip(), -1)
            if df < 0:
                df = 10000
            idf = math.log(10000000000 / df, 10)
            d_words[word][0] *= idf
        return d_words
        
    def get_topN_words(self, d_words):
        l_words=[]
        for tup in sorted(d_words.iteritems(), key = lambda x: x[1], reverse = True)[:20]:
            l_words.append(tup[0])
        '''
            for tup in sorted(d_words.iteritems(), key = lambda x: x[1], reverse = True):
                l_words.append(tup[0])
        '''
        return l_words
    def extract_feature(self,document):
        document=unicode(document,"utf-8")
        t1 = time.time()
        self.decode_document(document)
        logging.info('decode_document:')
        self.filter_doc()
        logging.info('filter_doc:')
        words=None
        try:
            logging.info("enter...")
            words1=jieba.analyse.textrank(document,topK=30)
            words2=jieba.analyse.extract_tags(document,topK=30)
            words=list(set(words1) | set(words2))
        except Exception as e:
            logging.info("exception")
            words=jieba.analyse.extract_tags(document,topK=30)
        d_words=[]
        for word in words:
            if len(word)>1:
                logging.info("%s"%(word))
                d_words.append(word)
        return d_words
        
        

    #优化的关键代码段,包含关键字的选取
    def extract_feature_bak(self, document):
        """
        这一步提取document特征，融合了以上几步
        """
        t1 = time.time()
        self.decode_document(document)
        logging.info('decode_document:')
        self.filter_doc()
        logging.info('filter_doc:')
        ll_words = self.word_posseg()
        logging.info('word_posseg:')
        #ll_words为数组的数组
        d_words = self.get_words_weight(ll_words)
        for word in d_words.items():
            logging.info('word weight %s,%s,%s'%(word[0],word[1][0],word[1][1]))
        logging.info('get_words_weight:')
        d_words = self.compute_idf(d_words)
        for word in d_words.items():
            logging.info('word tf-idf %s,%s,%s'%(word[0],word[1][0],word[1][1]))
        logging.info('compute_idf:')
        l_words = self.get_topN_words(d_words)
        logging.info("top word:"+" ".join(l_words))
        t2 = time.time()
        logging.info('get_topN_words:')
        logging.info("time of feature extraction is %ss" %(t2 - t1))
        logging.info("document features: \n %s" %(" ".join(l_words)))
        return l_words
    def decode_class_word(self, class_words):
        """
        这一步会加载类目词列表为实例属性
        """
        logging.info("enter decode_class_word")
        l_class_words = []
        if not len(class_words):
            logging.debug("class words list is null.")
            return l_class_words
        try:
            if type(class_words) == type(""):
                class_words = class_words.decode("utf-8")
        except Exception as e:
            traceback.print_exc()
            l_class_words = []
        l_class_words = [item.strip() for item in class_words.split(",")]
        logging.info("exit decode_class_word")
        return l_class_words

    def get_vec_cosine(self, vec1, vec2):
        cosi = 0.0
        L = min(len(vec1),len(vec2))
        M11 = 0.0
        M22 = 0.0
        M12 = 0.0
        for indx in range(L):
            M11 += math.pow(vec1[indx],2)
            M22 += math.pow(vec2[indx],2)
            M12 += vec1[indx] * vec2[indx]
        if math.sqrt((M11*M22)) == 0.0:
            return 0.0
        return math.fabs(M12/math.sqrt((M11*M22)))

    def det_weight(self,class_word_list,d_temp,doc_vec,ws):
        for class_word in class_word_list:
            class_word = class_word.strip()
            #classword在word2vec中不存在,但是class_word不为空
            if not len(self.get_word_vector(class_word.encode("utf-8"))) and len(class_word):
            #尝试分词处理
                l_cw = list(jieba.cut(class_word))
                max_w=1.0
                for cw in l_cw:
                    if cw in ws:
                        d_temp[class_word]=1.0
                        break
                    cw_vec = self.get_word_vector(cw.encode("utf-8"))
                    if cw_vec !=  list(np.zeros(dim)):
                        #将所有权重叠加到第一个关键词上
                        #d_temp[class_word] =d_temp.get(class_word,0.0)+self.get_vec_cosine(doc_vec, np.array(cw_vec))
                        weight=self.get_vec_cosine(doc_vec, np.array(cw_vec))
                        if weight<max_w:
                            d_temp[class_word]=weight
                        logging.info("det_weight in cut %s,%s"%(class_word,d_temp[class_word]))
            else:
                if class_word in ws:
                    d_temp[class_word]=1.0
                else:
                    clf_vec = self.get_word_vector(class_word.encode("utf-8"))
                    d_temp[class_word] = self.get_vec_cosine(doc_vec, np.array(clf_vec))
                    logging.info("det_weight %s,%s"%(class_word,d_temp[class_word]))
    def similarity(self,word1,word2):
        words1=word1.split("&") if "&" in word1 else word1.split("|")
        words2=word2.split("&") if "&" in word2 else word2.split("|")
        max=0.0
        for w1 in words1:
            for w2 in words2:
                vec1=self.get_word_vector(w1)
                vec2=self.get_word_vector(w2)
                tmp=self.get_vec_cosine(np.array(vec1), np.array(vec2))
                if max<tmp:
                    max=tmp
        return str(max) 
    def classify_doc(self, l_words,category_words, dim=150,sport=False):
        """
        服务器上必须将词转成utf-8才能调用w2v model
        """
        ret = {}
        '''
            类目关键词self.l_class_word,格式为 keyword1&keyword2  keyword1|keyword2  keyword
            &关系取关键词权重最小的，|关系取关键词权重最大的
            文章的top20的关键词为l_words
        '''
        '''
            首先计算文档向量            
        '''
        ws=set()
        doc_vec = np.zeros(dim)
        for word in l_words:
            w_w=word.split("|")
            if w_w[0] not in self.stopwords:
                word_vec = (float(w_w[1])*np.array(self.get_word_vector(w_w[0]))).tolist()
                doc_vec += word_vec
                if sport:
                    ws.add(unicode(w_w[0],"utf-8"))
        for class_word_str in category_words:
            tmp={}
            if u"&" in  class_word_str:
                #&逻辑,取最小的关键词的权重作为整个的权重
                class_word_list=class_word_str.split("&")
                self.det_weight(class_word_list,tmp,doc_vec,ws)
                sorted_tmp=sorted(tmp.iteritems(), key = lambda x:x[1], reverse = False)
                ret[class_word_str]=sorted_tmp[0][1]

            elif u"|" in class_word_str:
                #|逻辑
                class_word_list=class_word_str.split("|")
                self.det_weight(class_word_list,tmp,doc_vec,ws)
                sorted_tmp=sorted(tmp.iteritems(), key = lambda x:x[1], reverse = True)
                ret[class_word_str]=sorted_tmp[0][1]
            else:
                #正常逻辑
                class_word_list=class_word_str.split("-")
                self.det_weight(class_word_list,tmp,doc_vec,ws)
                sorted_tmp=sorted(tmp.iteritems(), key = lambda x:x[1], reverse = True)
                ret[class_word_str]=sorted_tmp[0][1]
                #self.det_weight_normal(class_word_list,ret,class_word_str,doc_vec,ws)
        class_result = sorted(ret.iteritems(), key = lambda x:x[1], reverse = True)
        res_class = [("其他", 1.0)]
        try:
            tmp=class_result[:3]
            for item in tmp:
                logging.info("%s: %f" %(item[0].encode("utf-8"), item[1]))
            res_class = tmp
        except Exception as e:
            traceback.print_exc()
        finally:
            res = json.dumps(res_class)
            if isinstance(res, unicode):
                res = res.encode('utf-8')
            return res
		
        
        
if __name__ == "__main__":
    w2vc = W2VClassify("stopwords.txt", "./model/baidu_df.txt", "../model_150_8.bin")
    test_str = """
    　　话说回来，对于高考结束后有着漫长三个月假期的同学来说，或许花一笔钱去考个无人机驾驶证也是值得的事情，毕竟技多不压身嘛～
    """
    l_words = w2vc.extract_feature(test_str)
    w2vc.decode_class_word("左,科技&技术,军事|飞机,民航 , IT, 人文社科, 经济管理, 教材")
    print w2vc.classify_doc(l_words)
