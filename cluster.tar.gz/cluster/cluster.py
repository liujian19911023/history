#!/usr/bin/python
#coding=utf-8

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import jieba
import sys, os, time
import numpy as np
reload(sys)
sys.setdefaultencoding('utf-8')

cur_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()


class Cluster(object):
    def __init__(self, stopwords_path='./cluster_stopwords.txt'):
        """
        加载停用词表
        """
        try:
            self.stopwords = set()
            with open(stopwords_path, 'r') as fp:
                for line in fp:
                    self.stopwords.add(line.strip().decode('utf-8'))
            self.stopwords = list(self.stopwords)
        except Exception as e:
            traceback.print_exc()
    
    """将带聚类数据分词,文章id以及索引做映射，以便后续kmeans使用"""
    def loadDataset(self, l_text):
        corpus=[]
        cnt=0
        #索引和文章id的映射
        cnt_iid={}
        for id_line in l_text:
            iid=id_line[0]
            cnt_iid[cnt]=iid
            line=id_line[1]
            if not isinstance(line,type(u'')):
                line=line.strip().decode()
            tmp=[word for word in list(jieba.cut(line))]
            corpus.append(" ".join(tmp))
            cnt+=1
        return corpus,cnt,cnt_iid
    
    """
    tfidf提取特征
    """
    def transform(self, dataset, stopwords, n_features=1000):
        vectorizer = TfidfVectorizer(max_df=0.5, max_features=n_features, min_df=0.02,use_idf=True,stop_words=stopwords)
        X = vectorizer.fit_transform(dataset)
        return X,vectorizer
    """
    一次kmeans训练，返回模型及其误差
    """
    def km_train(self, true_k, m, X):
        step=m/true_k
        init_array=np.array([])
        for i in range(true_k):
            idx=i*step
            if i*step!=0:
                idx=idx-1
            init_array=np.append(init_array,X[idx])
        init_array=init_array.reshape(true_k,len(init_array)/true_k)
        km = KMeans(n_clusters=true_k, init=init_array, max_iter=300, n_init=1,verbose=False)
        km.fit(X)
        err=sum(np.min(cdist(X, km.cluster_centers_, 'euclidean'), axis=1))/X.shape[0]
        return err,km
    """
    获取每个簇的中心词
    """
    def top_words(self, k, km, vectorizer, Y):
        centr_word={}
        order_centroids = km.cluster_centers_.argsort()[:, ::-1]
        terms = vectorizer.get_feature_names()
        for i in range(k):
            tmp=[]
            for ind in order_centroids[i, :10]:
                tmp.append(terms[ind])
            centr_word[i]=tmp
        result = list(km.predict(Y))
        d_ret={}
        for i in range(len(result)):
            tmp=d_ret.get(result[i],[])
            tmp.append(i)
            d_ret[result[i]]=tmp
        return d_ret,centr_word
    """
    kmeans聚类，循环中寻找最优的k值，不太准，后续可以优化
    """
    def train(self, X, vectorizer, true_k=None, minibatch=False, showLable=False):
        #使用采样数据还是原始数据训练k-means
        Y=X.toarray()
        m,n=Y.shape
        if true_k==None:
            error=sys.maxint
            k=6
            flag=False
            for true_k in range(4,30):
                if true_k>=m:
                    k=m
                    flag=True
                    break
                err,_= self.km_train(true_k,m,Y)
                if err>error:
                    if err-error>0.005:
                        k=true_k-1
                        flag=True
                        break
                if err<error:
                    if error-err<0.001:
                        k=true_k-1
                        flag=True
                        break
                error=err
            if not flag:
                k=29
            if k==m:
                k=m/3
            _,km = self.km_train(k,m,Y)
            d_ret,centr_word = self.top_words(k,km,vectorizer,Y)
            return d_ret,centr_word
        else:
            _,km=self.km_train(true_k,m,Y)
            d_ret,centr_word = self.top_words(true_k,km,vectorizer,Y)
            return d_ret,centr_word
    """
    输入为[[id,content],[]]结构
    """
            
    def main(self, l_text):
        dataset,cnt,cnt_iid = self.loadDataset(l_text)
        #根据文章数，确定tf-idf保留的特征数，拍脑袋的
        features=cnt*4
        X,vectorizer = self.transform(dataset,self.stopwords,n_features=features)
        ll_cluster,cluster_word = self.train(X,vectorizer,showLable=True)
        clusters={}
        centr_id={}
        for key in ll_cluster:
            lst=ll_cluster[key]
            tmp=[]
            for l in lst:
                tmp.append(cnt_iid[l])
                if not key in centr_id:
                    centr_id[key]=cnt_iid[l]
            clusters[key]=tmp
        return clusters,cluster_word,centr_id


if __name__=='__main__':

    cluster_obj = Cluster()
    t1=time.time()
    l_text=[]
    with open(sys.argv[1]) as f:
        for line in f:
            line=line.strip().decode().split('\t')
            l_text.append([line[0],line[1]])
    clusters,cluster_words,cent_id = cluster_obj.main(l_text)
    print clusters, '\n\n' ,cluster_words, '\n\n', cent_id, '\n\n'
